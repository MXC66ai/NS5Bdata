#! /bin/bash -i
for i in {1..82} ; do
  obabel -ipdbqt ../CHEMBL1142030_${i}.pdbqt -O ./CHEMBL1142030_${i}_.pdb -m
done

