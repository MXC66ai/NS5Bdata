#! /bin/bash -i
for i in {1..135} ; do
  vina --receptor ~/chembl-pdbqt/Palm-chembl/pdb/2giq_A_no_lig.pdbqt --ligand ~/chembl-pdbqt/Palm-chembl/CHEMBL1149391/CHEMBL1149391_${i}.pdbqt  --center_x 9.6  --center_y -7.7  --center_z -12.9  --size_x 15  --size_y 15  --size_z 15 --out CHEMBL1149391_${i}.pdbqt --log CHEMBL1149391_${i}.log
done
