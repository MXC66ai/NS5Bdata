#! /bin/bash -i
for i in {1..191} ; do
  vina --receptor ~/chembl-pdbqt/Palm-chembl/pdb/2giq_A_no_lig.pdbqt --ligand ~/chembl-pdbqt/Palm-chembl/CHEMBL1142034/CHEMBL1142034_${i}.pdbqt  --center_x 9.6  --center_y -7.7  --center_z -12.9  --size_x 15  --size_y 15  --size_z 15 --out CHEMBL1142034_${i}.pdbqt --log CHEMBL1142034_${i}.log
done
